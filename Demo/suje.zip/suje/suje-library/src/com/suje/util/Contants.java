package com.suje.util;

import android.os.Environment;

/**
 * Created by zqmao on 2017/8/6.
 */

public class Contants {

    public static final String FILE_DOWNLOAD_PATH = Environment.getExternalStorageDirectory().getPath() + "/Isuje/";
    public static final String FILE_CHUNKS_PATH = Environment.getExternalStorageDirectory().getPath() + "/Isuje/Chunk/";

}
