package com.suje.db;

/**
 * Created by zqmao on 2017/8/6.
 */

public class JsFileDown extends JsFile {

}
