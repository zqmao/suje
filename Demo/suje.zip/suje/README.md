# suje
文件上传下载

使用的网络框架是AsyncHttpClient，后期可能需要改成HttpUrlConnection
